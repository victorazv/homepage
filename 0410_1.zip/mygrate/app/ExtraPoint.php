<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExtraPoint extends Model
{
    protected $table = 'mygrt_list_extrapoint';
}
