<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnglishTests extends Model
{
    protected $table = 'mygrt_list_english_tests';
}
