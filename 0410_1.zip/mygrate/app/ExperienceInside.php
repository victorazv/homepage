<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExperienceInside extends Model
{
    protected $table = 'mygrt_list_inside';
}
