<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExperienceOutside extends Model
{
    protected $table = 'mygrt_list_outside';
}
