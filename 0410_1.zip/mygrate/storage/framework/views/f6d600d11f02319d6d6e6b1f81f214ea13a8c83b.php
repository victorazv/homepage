<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mygrate</title>

    <link href="https://fonts.googleapis.com/css?family=Muli:200,300,400,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.9/css/all.css"
          integrity="sha384-5SOiIsAziJl6AWe0HWRKTXlfcSHKmYV4RBF18PPJ173Kzn7jzMyFuTtk8JA7QQG1" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Estilo do Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-4/css/bootstrap.css')); ?>">
    <!-- Estilo de trabalho -->
    <link rel="stylesheet" href="<?php echo e(asset('css/estilo2.css')); ?>">    
    
    <link rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    
    <?php echo $__env->yieldPushContent('header-scripts'); ?>
</head>
<body>

<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('footer'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap-4/js/bootstrap.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('footer-scripts'); ?>
</body>
</html>