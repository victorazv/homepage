<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form_style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="mb-3 animated bounceInRight">
	<section  id="sec_1" class="how-it-works py-3">
		<div class="container">
			<div class="row d-sm-flex justify-content-center">
				<div class="col-md-4 px-0 pr-md-3 flex-wrap sec_1">
					<div class="sec_3 col-md-12 ">
						<div class="mt-4 ml-2">
							<img src="images/img_form_01.png" class="d-none d-md-block" alt="paper">
						</div>
						<p class="col-12 col-md-8 ml-md-3 pl-0 pl-md-3">
							<img src="images/img1_small.png" class=" d-sm-none">
							<span class="card_title d-none d-md-block">Things you need to know</span>
							<span class="card_title2 d-sm-none">Things you need to know</span>
						</p>
					</div>
				</div>
				<div class="col-xs-12 col-md-5 pr-md-0 mt-4 d-flex flex-wrap">
					<div class="w-100 my-5 col-xs-1 flex-xs-nowrap d-none d-md-block">
						<img src="images/icon_i.png">
					</div>
					<h5 class="text_sec_1 mb-4 offset-xs-2 col-xs-10">
						This section will go through the usual legal stuff.
					</h5>
					<h5 class="text_sec_1 mb-4"> 
						Some of the Australian Visas require a
						mandatory, satisfactory skills assessment from
						the relevant assessing authority for your
						occupation.
					</h5>
					<h5 class="text_sec_1 mb-4">
						Not every Visa is points-based and not every
						Visa requires a skills assessment.
						However, this form will consider all the options in
						order to cover each possibility.
					</h5>
				</div>
			</div>
		</div>

		<div class="question w-100 offset-md-2 col-md-8 col-xs-12">
			<a href="/paf1a"><button class="float-right mt-3 mr-4">Continue</button></a>
		</div>

		<div class="percent_bar col-12 pl-0 d-flex">
			<div class="offset-1 offset-md-2 col-6 col-md-7 mt-3 pl-0">
				<span class="el_percentage">0%</span> Completed
				<div class="progress progress2">
					<div class="progress-bar" role="progressbar" style="" aria-valuenow="" aria-valuemin="0" aria-valuemax="100"></div>
				</div>
			</div>
			<div class="col-md-2 mt-2 pl-0">
				<img src="images/img_previous_blocked.png">
				<a href="/paf1a" id="btn_1"><img src="images/img_next.png"></a>
			</div>
		</div>
	</section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    
<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('js/form.js')); ?>"></script>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>